window.YTD.tweet.part0 = [ {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "1036183783488278531",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1036183783488278531",
  "created_at" : "Sun Sep 02 09:27:20 +0000 2018",
  "favorited" : false,
  "full_text" : "\"for the old testament's part, there is nothing intrinsically about god.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Lite</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ "0", "9" ],
      "id_str" : "44196397",
      "id" : "44196397"
    }, {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "indices" : [ "10", "19" ],
      "id_str" : "15492359",
      "id" : "15492359"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "32" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "880201693496987648",
  "id_str" : "962635160012427265",
  "in_reply_to_user_id" : "44196397",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "962635160012427265",
  "in_reply_to_status_id" : "880201693496987648",
  "created_at" : "Sun Feb 11 10:31:21 +0000 2018",
  "favorited" : false,
  "full_text" : "@elonmusk @TEDTalks Wat the fuck",
  "lang" : "en",
  "in_reply_to_screen_name" : "elonmusk",
  "in_reply_to_user_id_str" : "44196397"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/7FUwoIhRaO",
      "expanded_url" : "http://gophone.reloadcodes.com",
      "display_url" : "gophone.reloadcodes.com",
      "indices" : [ "35", "58" ]
    } ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "0",
  "id_str" : "893019831280308224",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "893019831280308224",
  "possibly_sensitive" : true,
  "created_at" : "Thu Aug 03 08:04:53 +0000 2017",
  "favorited" : false,
  "full_text" : "Time to put minutes on my Go Phone https://t.co/7FUwoIhRaO :D",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/lpTQT5MEZH",
      "expanded_url" : "http://gophone.reloadcodes.com/",
      "display_url" : "gophone.reloadcodes.com",
      "indices" : [ "27", "50" ]
    } ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "893015632081539073",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "893015632081539073",
  "possibly_sensitive" : true,
  "created_at" : "Thu Aug 03 07:48:12 +0000 2017",
  "favorited" : false,
  "full_text" : "Free Go Phone Reload Codes https://t.co/lpTQT5MEZH",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ "0", "8" ],
      "id_str" : "1652541",
      "id" : "1652541"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "31" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "833837425893982208",
  "id_str" : "833837559532904448",
  "in_reply_to_user_id" : "1652541",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "833837559532904448",
  "in_reply_to_status_id" : "833837425893982208",
  "created_at" : "Tue Feb 21 00:35:40 +0000 2017",
  "favorited" : false,
  "full_text" : "@Reuters \nWat is this all about",
  "lang" : "en",
  "in_reply_to_screen_name" : "Reuters",
  "in_reply_to_user_id_str" : "1652541"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ "0", "6" ],
      "id_str" : "38679388",
      "id" : "38679388"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "33" ],
  "favorite_count" : "0",
  "id_str" : "833344625351987201",
  "in_reply_to_user_id" : "38679388",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "833344625351987201",
  "created_at" : "Sun Feb 19 15:56:56 +0000 2017",
  "favorited" : false,
  "full_text" : "@gmail my name is Justin not John",
  "lang" : "en",
  "in_reply_to_screen_name" : "gmail",
  "in_reply_to_user_id_str" : "38679388"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ "0", "8" ],
      "id_str" : "1652541",
      "id" : "1652541"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "93" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "833335659150573568",
  "id_str" : "833339299626115072",
  "in_reply_to_user_id" : "1652541",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "833339299626115072",
  "in_reply_to_status_id" : "833335659150573568",
  "created_at" : "Sun Feb 19 15:35:46 +0000 2017",
  "favorited" : false,
  "full_text" : "@Reuters I need help straighting out this and all my social media accounts this is my account",
  "lang" : "en",
  "in_reply_to_screen_name" : "Reuters",
  "in_reply_to_user_id_str" : "1652541"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Purvi Roshu",
      "screen_name" : "PurviRoshu",
      "indices" : [ "0", "11" ],
      "id_str" : "3360955820",
      "id" : "3360955820"
    }, {
      "name" : "Periscope",
      "screen_name" : "PeriscopeCo",
      "indices" : [ "12", "24" ],
      "id_str" : "2445809510",
      "id" : "2445809510"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "32" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "829751375949033472",
  "id_str" : "833295541597564928",
  "in_reply_to_user_id" : "3360955820",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "833295541597564928",
  "in_reply_to_status_id" : "829751375949033472",
  "created_at" : "Sun Feb 19 12:41:53 +0000 2017",
  "favorited" : false,
  "full_text" : "@PurviRoshu @periscopeco wats up",
  "lang" : "en",
  "in_reply_to_screen_name" : "PurviRoshu",
  "in_reply_to_user_id_str" : "3360955820"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Purvi Roshu",
      "screen_name" : "PurviRoshu",
      "indices" : [ "0", "11" ],
      "id_str" : "3360955820",
      "id" : "3360955820"
    }, {
      "name" : "Periscope",
      "screen_name" : "PeriscopeCo",
      "indices" : [ "12", "24" ],
      "id_str" : "2445809510",
      "id" : "2445809510"
    }, {
      "name" : "Justin",
      "screen_name" : "justin71772511",
      "indices" : [ "25", "40" ],
      "id_str" : "860353831",
      "id" : "860353831"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "829751375949033472",
  "id_str" : "833295477374386176",
  "in_reply_to_user_id" : "3360955820",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "833295477374386176",
  "in_reply_to_status_id" : "829751375949033472",
  "created_at" : "Sun Feb 19 12:41:38 +0000 2017",
  "favorited" : false,
  "full_text" : "@PurviRoshu @periscopeco @justin71772511",
  "lang" : "und",
  "in_reply_to_screen_name" : "PurviRoshu",
  "in_reply_to_user_id_str" : "3360955820"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "5" ],
  "favorite_count" : "0",
  "id_str" : "833291648431972352",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "833291648431972352",
  "created_at" : "Sun Feb 19 12:26:25 +0000 2017",
  "favorited" : false,
  "full_text" : "Hello",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/rl7gVRgRf0",
      "expanded_url" : "https://squareup.com/dreams/yassin",
      "display_url" : "squareup.com/dreams/yassin",
      "indices" : [ "0", "23" ]
    } ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "832654103511699456",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "832654103511699456",
  "possibly_sensitive" : true,
  "created_at" : "Fri Feb 17 18:13:02 +0000 2017",
  "favorited" : false,
  "full_text" : "https://t.co/rl7gVRgRf0",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Lite</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "thank",
      "indices" : [ "13", "19" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ "0", "12" ],
      "id_str" : "17266725",
      "id" : "17266725"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "804699921165103110",
  "id_str" : "804784137211088898",
  "in_reply_to_user_id" : "17266725",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "804784137211088898",
  "in_reply_to_status_id" : "804699921165103110",
  "created_at" : "Fri Dec 02 20:27:45 +0000 2016",
  "favorited" : false,
  "full_text" : "@TonyRobbins #thank you",
  "lang" : "und",
  "in_reply_to_screen_name" : "TonyRobbins",
  "in_reply_to_user_id_str" : "17266725"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Lite</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wayne Kramer",
      "screen_name" : "waynekramer",
      "indices" : [ "0", "12" ],
      "id_str" : "90694294",
      "id" : "90694294"
    }, {
      "name" : "Demon Matt",
      "screen_name" : "alicecarbtench",
      "indices" : [ "13", "28" ],
      "id_str" : "862252068135895040",
      "id" : "862252068135895040"
    }, {
      "name" : "benmont tench III",
      "screen_name" : "benchten",
      "indices" : [ "29", "38" ],
      "id_str" : "158644390",
      "id" : "158644390"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "802523623609090048",
  "id_str" : "804783401135964161",
  "in_reply_to_user_id" : "90694294",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "804783401135964161",
  "in_reply_to_status_id" : "802523623609090048",
  "created_at" : "Fri Dec 02 20:24:49 +0000 2016",
  "favorited" : false,
  "full_text" : "@waynekramer @alicecarbtench @benchten @Justin7177251",
  "lang" : "und",
  "in_reply_to_screen_name" : "waynekramer",
  "in_reply_to_user_id_str" : "90694294"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Lite</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "wats",
      "indices" : [ "0", "5" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "22" ],
  "favorite_count" : "0",
  "id_str" : "804782845927587841",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "804782845927587841",
  "created_at" : "Fri Dec 02 20:22:37 +0000 2016",
  "favorited" : false,
  "full_text" : "#wats up # hello world",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "11" ],
  "favorite_count" : "2",
  "id_str" : "773081512615043076",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "773081512615043076",
  "created_at" : "Tue Sep 06 08:52:50 +0000 2016",
  "favorited" : false,
  "full_text" : "I found you",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/justin7177251/status/772557540009795584/photo/1",
      "indices" : [ "2", "25" ],
      "url" : "https://t.co/jKwAy4MV1p",
      "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Cris8LKVIAAjhSS.jpg",
      "id_str" : "772557485882286080",
      "id" : "772557485882286080",
      "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Cris8LKVIAAjhSS.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "212",
          "h" : "212",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "212",
          "h" : "212",
          "resize" : "fit"
        },
        "small" : {
          "w" : "212",
          "h" : "212",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/jKwAy4MV1p"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "25" ],
  "favorite_count" : "1",
  "id_str" : "772557540009795584",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "772557540009795584",
  "possibly_sensitive" : false,
  "created_at" : "Sun Sep 04 22:10:45 +0000 2016",
  "favorited" : false,
  "full_text" : "@ https://t.co/jKwAy4MV1p",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/justin7177251/status/772557540009795584/photo/1",
      "indices" : [ "2", "25" ],
      "url" : "https://t.co/jKwAy4MV1p",
      "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Cris8LKVIAAjhSS.jpg",
      "id_str" : "772557485882286080",
      "video_info" : {
        "aspect_ratio" : [ "1", "1" ],
        "variants" : [ {
          "bitrate" : "0",
          "content_type" : "video/mp4",
          "url" : "https://video.twimg.com/tweet_video/Cris8LKVIAAjhSS.mp4"
        } ]
      },
      "id" : "772557485882286080",
      "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Cris8LKVIAAjhSS.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "212",
          "h" : "212",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "212",
          "h" : "212",
          "resize" : "fit"
        },
        "small" : {
          "w" : "212",
          "h" : "212",
          "resize" : "fit"
        }
      },
      "type" : "animated_gif",
      "display_url" : "pic.twitter.com/jKwAy4MV1p"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Relationships \uD83E\uDD40",
      "screen_name" : "ohteenquotes",
      "indices" : [ "0", "13" ],
      "id_str" : "89423854",
      "id" : "89423854"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "13" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "772187473342521344",
  "id_str" : "772557125113352192",
  "in_reply_to_user_id" : "89423854",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "772557125113352192",
  "in_reply_to_status_id" : "772187473342521344",
  "created_at" : "Sun Sep 04 22:09:06 +0000 2016",
  "favorited" : false,
  "full_text" : "@ohteenquotes",
  "lang" : "und",
  "in_reply_to_screen_name" : "ohteenquotes",
  "in_reply_to_user_id_str" : "89423854"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Leslie Jones \uD83E\uDD8B",
      "screen_name" : "Lesdoggg",
      "indices" : [ "0", "9" ],
      "id_str" : "47216804",
      "id" : "47216804"
    } ],
    "urls" : [ {
      "url" : "https://t.co/kIuL76ecqz",
      "expanded_url" : "http://www.funguppy.com/m.php?m=6f8917&p=swarm",
      "display_url" : "funguppy.com/m.php?m=6f8917…",
      "indices" : [ "10", "33" ]
    } ]
  },
  "display_text_range" : [ "0", "33" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "772486372800270336",
  "id_str" : "772557008641728512",
  "in_reply_to_user_id" : "47216804",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "772557008641728512",
  "in_reply_to_status_id" : "772486372800270336",
  "possibly_sensitive" : false,
  "created_at" : "Sun Sep 04 22:08:38 +0000 2016",
  "favorited" : false,
  "full_text" : "@Lesdoggg https://t.co/kIuL76ecqz",
  "lang" : "und",
  "in_reply_to_screen_name" : "Lesdoggg",
  "in_reply_to_user_id_str" : "47216804"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ "0", "11" ],
      "id_str" : "29442313",
      "id" : "29442313"
    } ],
    "urls" : [ {
      "url" : "https://t.co/kIuL76ecqz",
      "expanded_url" : "http://www.funguppy.com/m.php?m=6f8917&p=swarm",
      "display_url" : "funguppy.com/m.php?m=6f8917…",
      "indices" : [ "12", "35" ]
    } ]
  },
  "display_text_range" : [ "0", "35" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "772504757000962049",
  "id_str" : "772556677878919168",
  "in_reply_to_user_id" : "29442313",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "772556677878919168",
  "in_reply_to_status_id" : "772504757000962049",
  "possibly_sensitive" : false,
  "created_at" : "Sun Sep 04 22:07:20 +0000 2016",
  "favorited" : false,
  "full_text" : "@SenSanders https://t.co/kIuL76ecqz",
  "lang" : "und",
  "in_reply_to_screen_name" : "SenSanders",
  "in_reply_to_user_id_str" : "29442313"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "indices" : [ "0", "7" ],
      "id_str" : "16228398",
      "id" : "16228398"
    }, {
      "name" : "Texas_Blu",
      "screen_name" : "txbluinfo",
      "indices" : [ "8", "18" ],
      "id_str" : "746546285402955776",
      "id" : "746546285402955776"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "18" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "772477338898558976",
  "id_str" : "772556507296563200",
  "in_reply_to_user_id" : "16228398",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "772556507296563200",
  "in_reply_to_status_id" : "772477338898558976",
  "created_at" : "Sun Sep 04 22:06:39 +0000 2016",
  "favorited" : false,
  "full_text" : "@mcuban @txbluinfo",
  "lang" : "und",
  "in_reply_to_screen_name" : "mcuban",
  "in_reply_to_user_id_str" : "16228398"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Justin morgan",
      "screen_name" : "Justinm74231215",
      "indices" : [ "0", "16" ],
      "id_str" : "710896396824657920",
      "id" : "710896396824657920"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "16" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "710898065784365057",
  "id_str" : "772422462789279744",
  "in_reply_to_user_id" : "710896396824657920",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "772422462789279744",
  "in_reply_to_status_id" : "710898065784365057",
  "created_at" : "Sun Sep 04 13:14:00 +0000 2016",
  "favorited" : false,
  "full_text" : "@Justinm74231215",
  "lang" : "und",
  "in_reply_to_screen_name" : "Justinm74231215",
  "in_reply_to_user_id_str" : "710896396824657920"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "35" ],
  "favorite_count" : "0",
  "id_str" : "772420634844553216",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "772420634844553216",
  "created_at" : "Sun Sep 04 13:06:44 +0000 2016",
  "favorited" : false,
  "full_text" : "I'm greatful for this beautiful day",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/re9QDiQynp",
      "expanded_url" : "http://www.bbc.com/zhongwen/simp",
      "display_url" : "bbc.com/zhongwen/simp",
      "indices" : [ "0", "23" ]
    } ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "8",
  "id_str" : "771037772757032960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "771037772757032960",
  "possibly_sensitive" : false,
  "created_at" : "Wed Aug 31 17:31:44 +0000 2016",
  "favorited" : false,
  "full_text" : "https://t.co/re9QDiQynp",
  "lang" : "und"
} ]