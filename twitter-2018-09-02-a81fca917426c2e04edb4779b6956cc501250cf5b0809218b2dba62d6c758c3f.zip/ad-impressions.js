window.YTD.ad_impressions.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "adImpressions" : {
        "impressions" : [ {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "991747686666661888",
            "tweetText" : "Modern styling, illuminated.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Genesis USA",
            "screenName" : "@GenesisUSA"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Interests",
            "targetingValue" : "Automotive news and general info"
          }, {
            "targetingType" : "Age",
            "targetingValue" : "25 and up"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "United States"
          }, {
            "targetingType" : "Platforms",
            "targetingValue" : "Android"
          } ],
          "impressionTime" : "2018-08-12 20:25:03"
        }, {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "968941218305515520",
            "tweetText" : "Linked to a Schwab One® brokerage account, Schwab Bank’s checking account makes managing your finances simpler.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Charles Schwab Corp",
            "screenName" : "@CharlesSchwab"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Interests",
            "targetingValue" : "Beginning investing"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Financial news"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Financial planning"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Investing"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Mutual funds"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Options"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Business and finance"
          }, {
            "targetingType" : "Tailored audiences (lists)",
            "targetingValue" : "Charles Schwab Master Account List_1_13318139"
          }, {
            "targetingType" : "Age",
            "targetingValue" : "25 to 49"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "United States"
          } ],
          "impressionTime" : "2018-08-12 20:26:38"
        }, {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1016419141757100033",
            "tweetText" : "No time to let up? e-Pedal saves you the trouble of switching pedals. And, of course, your brake pedal is still there so you can brake on demand. Find it on the all-new 2018 Nissan LEAF.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Nissan",
            "screenName" : "@NissanUSA"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Interests",
            "targetingValue" : "Entrepreneurship"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Small business"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Business news and general info"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Bottled water"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Coffee: k-cup"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Corporate execs"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Business travelers"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Armani"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Household income: $20,000 - $29,999"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Household income: $30,000 - $39,999"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Big Shots - Young Upmarket Urbanites: M64"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Champagne Tastes - Executive Empty Nesters: O69"
          }, {
            "targetingType" : "Behaviors",
            "targetingValue" : "US - Country Club Climbers - Suburban Empty Nesters: K59"
          }, {
            "targetingType" : "Age",
            "targetingValue" : "18 to 54"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "United States"
          } ],
          "impressionTime" : "2018-08-12 20:27:27"
        }, {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1026908724789739520",
            "tweetText" : "$0 fee to change your flight** $0 to check your bags*** 0 hidden fees - always.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Southwest Airlines",
            "screenName" : "@SouthwestAir"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Interests",
            "targetingValue" : "Adventure travel"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Business travel"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "National parks"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Travel news and general info"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "United States"
          } ],
          "impressionTime" : "2018-08-12 20:26:24"
        }, {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "989522531601276928",
            "tweetText" : "Visual recognition of plot and satellite imagery can help farmers increase their yields. https://t.co/qs2DvC6Iic",
            "urls" : [ "https://t.co/qs2DvC6Iic" ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "IBM",
            "screenName" : "@IBM"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Interests",
            "targetingValue" : "Computer networking"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Databases"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Network security"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Open source"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "United States"
          } ],
          "impressionTime" : "2018-08-12 20:27:13"
        }, {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1024010373085753344",
            "tweetText" : "Earn more points at more hotels around the world with the IHG® Rewards Club Premier Credit Card.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "IHG Rewards Club",
            "screenName" : "@ihgrewardsclub"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Interests",
            "targetingValue" : "Adventure travel"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Business travel"
          }, {
            "targetingType" : "Interests",
            "targetingValue" : "Luxury travel"
          }, {
            "targetingType" : "Age",
            "targetingValue" : "25 and up"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "United States"
          } ],
          "impressionTime" : "2018-08-12 20:27:02"
        } ]
      }
    }
  }
} ]