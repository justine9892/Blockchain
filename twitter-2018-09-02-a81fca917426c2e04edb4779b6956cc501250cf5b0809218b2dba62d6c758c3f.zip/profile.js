window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "I'm a investor",
      "website" : "https://t.co/amL96aHQl8",
      "location" : "Alabama, USA"
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/770977648935862273/jE6aoFbm.jpg"
  }
} ]