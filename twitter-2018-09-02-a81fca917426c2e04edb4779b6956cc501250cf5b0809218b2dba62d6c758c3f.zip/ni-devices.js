window.YTD.ni_devices.part0 = [ {
  "niDeviceResponse" : {
    "pushDevice" : {
      "deviceType" : "Web",
      "createdDate" : "2017.10.28",
      "updatedDate" : "2017.10.28"
    }
  }
} ]