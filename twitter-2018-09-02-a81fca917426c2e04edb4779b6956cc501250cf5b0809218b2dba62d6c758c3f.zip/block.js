window.YTD.block.part0 = [ {
  "blocking" : {
    "accountId" : "44196397"
  }
}, {
  "blocking" : {
    "accountId" : "103550181"
  }
} ]