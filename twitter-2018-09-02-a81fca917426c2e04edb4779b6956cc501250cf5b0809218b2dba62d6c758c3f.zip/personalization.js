window.YTD.personalization.part0 = [ {
  "p13nData" : {
    "demographics" : {
      "languages" : [ {
        "language" : "English",
        "isDisabled" : false
      } ],
      "genderInfo" : {
        "gender" : "male"
      }
    },
    "interests" : {
      "interests" : [ {
        "name" : "Accounting News",
        "isDisabled" : false
      }, {
        "name" : "Action sports",
        "isDisabled" : false
      }, {
        "name" : "Actors and Actresses",
        "isDisabled" : false
      }, {
        "name" : "Adele",
        "isDisabled" : false
      }, {
        "name" : "Adele Live in New York City",
        "isDisabled" : false
      }, {
        "name" : "Adventure travel",
        "isDisabled" : false
      }, {
        "name" : "American Idol",
        "isDisabled" : false
      }, {
        "name" : "American Idol",
        "isDisabled" : false
      }, {
        "name" : "American Idol",
        "isDisabled" : false
      }, {
        "name" : "Animation",
        "isDisabled" : false
      }, {
        "name" : "Antivirus",
        "isDisabled" : false
      }, {
        "name" : "Arts and crafts",
        "isDisabled" : false
      }, {
        "name" : "Asia",
        "isDisabled" : false
      }, {
        "name" : "Automotive news and general info",
        "isDisabled" : false
      }, {
        "name" : "Barack Obama",
        "isDisabled" : false
      }, {
        "name" : "Barack Obama",
        "isDisabled" : false
      }, {
        "name" : "Baseball",
        "isDisabled" : false
      }, {
        "name" : "Beginning investing",
        "isDisabled" : false
      }, {
        "name" : "Biographies and memoirs",
        "isDisabled" : false
      }, {
        "name" : "Biology",
        "isDisabled" : false
      }, {
        "name" : "Books news and general info",
        "isDisabled" : false
      }, {
        "name" : "Business News",
        "isDisabled" : false
      }, {
        "name" : "Business and finance",
        "isDisabled" : false
      }, {
        "name" : "Business and news",
        "isDisabled" : false
      }, {
        "name" : "Business news and general info",
        "isDisabled" : false
      }, {
        "name" : "Business software",
        "isDisabled" : false
      }, {
        "name" : "Business travel",
        "isDisabled" : false
      }, {
        "name" : "Career news and general info",
        "isDisabled" : false
      }, {
        "name" : "Cell phones",
        "isDisabled" : false
      }, {
        "name" : "Comedians",
        "isDisabled" : false
      }, {
        "name" : "Comedy",
        "isDisabled" : false
      }, {
        "name" : "Comedy",
        "isDisabled" : false
      }, {
        "name" : "Comics",
        "isDisabled" : false
      }, {
        "name" : "Commentary",
        "isDisabled" : false
      }, {
        "name" : "Computer certification",
        "isDisabled" : false
      }, {
        "name" : "Computer gaming",
        "isDisabled" : false
      }, {
        "name" : "Computer networking",
        "isDisabled" : false
      }, {
        "name" : "Computer programming",
        "isDisabled" : false
      }, {
        "name" : "Computer reviews",
        "isDisabled" : false
      }, {
        "name" : "Cricket",
        "isDisabled" : false
      }, {
        "name" : "CrowdFunding News",
        "isDisabled" : false
      }, {
        "name" : "Cryptocurrency",
        "isDisabled" : false
      }, {
        "name" : "Data centers",
        "isDisabled" : false
      }, {
        "name" : "Databases",
        "isDisabled" : false
      }, {
        "name" : "Design",
        "isDisabled" : false
      }, {
        "name" : "Documentary",
        "isDisabled" : false
      }, {
        "name" : "Dogs",
        "isDisabled" : false
      }, {
        "name" : "Drawing and sketching",
        "isDisabled" : false
      }, {
        "name" : "Economics and Finance",
        "isDisabled" : false
      }, {
        "name" : "Education news and general info",
        "isDisabled" : false
      }, {
        "name" : "Entertaining at home",
        "isDisabled" : false
      }, {
        "name" : "Entertainment awards",
        "isDisabled" : false
      }, {
        "name" : "Entrepreneurship",
        "isDisabled" : false
      }, {
        "name" : "Europe",
        "isDisabled" : false
      }, {
        "name" : "Exercise and fitness",
        "isDisabled" : false
      }, {
        "name" : "Financial news",
        "isDisabled" : false
      }, {
        "name" : "Financial planning",
        "isDisabled" : false
      }, {
        "name" : "Fitness & Wellness",
        "isDisabled" : false
      }, {
        "name" : "Food Brands",
        "isDisabled" : false
      }, {
        "name" : "Foodie news and general info",
        "isDisabled" : false
      }, {
        "name" : "Freelance writing",
        "isDisabled" : false
      }, {
        "name" : "Gaming News",
        "isDisabled" : false
      }, {
        "name" : "Gaming news and general info",
        "isDisabled" : false
      }, {
        "name" : "General News",
        "isDisabled" : false
      }, {
        "name" : "Geography",
        "isDisabled" : false
      }, {
        "name" : "Geology",
        "isDisabled" : false
      }, {
        "name" : "Gov Officials & Agencies",
        "isDisabled" : false
      }, {
        "name" : "Government",
        "isDisabled" : false
      }, {
        "name" : "Government resources",
        "isDisabled" : false
      }, {
        "name" : "Health news and general info",
        "isDisabled" : false
      }, {
        "name" : "Hip-Hop/Rap",
        "isDisabled" : false
      }, {
        "name" : "Holidays",
        "isDisabled" : false
      }, {
        "name" : "Home entertainment",
        "isDisabled" : false
      }, {
        "name" : "Hybrid and electric vehicles",
        "isDisabled" : false
      }, {
        "name" : "Independent",
        "isDisabled" : false
      }, {
        "name" : "Indian Brands on Twitter",
        "isDisabled" : false
      }, {
        "name" : "Industry News",
        "isDisabled" : false
      }, {
        "name" : "Investing",
        "isDisabled" : false
      }, {
        "name" : "Job search",
        "isDisabled" : false
      }, {
        "name" : "Kids' apparel",
        "isDisabled" : false
      }, {
        "name" : "Language learning",
        "isDisabled" : false
      }, {
        "name" : "Latino Music",
        "isDisabled" : false
      }, {
        "name" : "Leadership",
        "isDisabled" : false
      }, {
        "name" : "Legal issues",
        "isDisabled" : false
      }, {
        "name" : "Luxury travel",
        "isDisabled" : false
      }, {
        "name" : "Microsoft",
        "isDisabled" : false
      }, {
        "name" : "Mobile",
        "isDisabled" : false
      }, {
        "name" : "Movies / Tv / Radio",
        "isDisabled" : false
      }, {
        "name" : "Music",
        "isDisabled" : false
      }, {
        "name" : "Music",
        "isDisabled" : false
      }, {
        "name" : "Music",
        "isDisabled" : false
      }, {
        "name" : "Music festivals and concerts",
        "isDisabled" : false
      }, {
        "name" : "Music news and general info",
        "isDisabled" : false
      }, {
        "name" : "Mutual funds",
        "isDisabled" : false
      }, {
        "name" : "NBA",
        "isDisabled" : false
      }, {
        "name" : "National parks",
        "isDisabled" : false
      }, {
        "name" : "Network security",
        "isDisabled" : false
      }, {
        "name" : "News / Politics",
        "isDisabled" : false
      }, {
        "name" : "News and Media",
        "isDisabled" : false
      }, {
        "name" : "Nonfiction",
        "isDisabled" : false
      }, {
        "name" : "Nonprofit",
        "isDisabled" : false
      }, {
        "name" : "Nonprofits & Foundations",
        "isDisabled" : false
      }, {
        "name" : "Offroad vehicles",
        "isDisabled" : false
      }, {
        "name" : "Online education",
        "isDisabled" : false
      }, {
        "name" : "Open source",
        "isDisabled" : false
      }, {
        "name" : "Options",
        "isDisabled" : false
      }, {
        "name" : "Painting",
        "isDisabled" : false
      }, {
        "name" : "Photography",
        "isDisabled" : false
      }, {
        "name" : "Physics",
        "isDisabled" : false
      }, {
        "name" : "Political elections",
        "isDisabled" : false
      }, {
        "name" : "Politics",
        "isDisabled" : false
      }, {
        "name" : "Politics",
        "isDisabled" : false
      }, {
        "name" : "Politics and current events",
        "isDisabled" : false
      }, {
        "name" : "Pop",
        "isDisabled" : false
      }, {
        "name" : "R&B/Soul",
        "isDisabled" : false
      }, {
        "name" : "Reality TV",
        "isDisabled" : false
      }, {
        "name" : "Rock/Alt",
        "isDisabled" : false
      }, {
        "name" : "SEO & Online Marketing",
        "isDisabled" : false
      }, {
        "name" : "Sci-fi and fantasy",
        "isDisabled" : false
      }, {
        "name" : "Sci-fi and fantasy",
        "isDisabled" : false
      }, {
        "name" : "Science",
        "isDisabled" : false
      }, {
        "name" : "Science news",
        "isDisabled" : false
      }, {
        "name" : "Screenwriting",
        "isDisabled" : false
      }, {
        "name" : "Skin care",
        "isDisabled" : false
      }, {
        "name" : "Small business",
        "isDisabled" : false
      }, {
        "name" : "Space and astronomy",
        "isDisabled" : false
      }, {
        "name" : "Sporting events",
        "isDisabled" : false
      }, {
        "name" : "Sporting goods",
        "isDisabled" : false
      }, {
        "name" : "Sports news",
        "isDisabled" : false
      }, {
        "name" : "Sports themed",
        "isDisabled" : false
      }, {
        "name" : "Startups",
        "isDisabled" : false
      }, {
        "name" : "Taylor Swift",
        "isDisabled" : false
      }, {
        "name" : "Taylor Swift",
        "isDisabled" : false
      }, {
        "name" : "Taylor Swift releases \"Call It What You Want\" from her upcoming album",
        "isDisabled" : false
      }, {
        "name" : "Tech News",
        "isDisabled" : false
      }, {
        "name" : "Tech news",
        "isDisabled" : false
      }, {
        "name" : "Tech tradeshows",
        "isDisabled" : false
      }, {
        "name" : "Technology",
        "isDisabled" : false
      }, {
        "name" : "Technology",
        "isDisabled" : false
      }, {
        "name" : "Television",
        "isDisabled" : false
      }, {
        "name" : "Travel news and general info",
        "isDisabled" : false
      }, {
        "name" : "Trending",
        "isDisabled" : false
      }, {
        "name" : "UK Fashion and Beauty",
        "isDisabled" : false
      }, {
        "name" : "US News",
        "isDisabled" : false
      }, {
        "name" : "Vintage cars",
        "isDisabled" : false
      }, {
        "name" : "Weather",
        "isDisabled" : false
      }, {
        "name" : "Web design",
        "isDisabled" : false
      }, {
        "name" : "World News",
        "isDisabled" : false
      } ],
      "partnerInterests" : [ {
        "name" : "Auto > Auto parts buyer"
      }, {
        "name" : "Auto > Domestic luxury vehicle owners"
      }, {
        "name" : "Auto > Reliable auto loan payers"
      }, {
        "name" : "Auto > Vehicle price: $20k to $30k"
      }, {
        "name" : "CPG BuyStyles > Quick & easy"
      }, {
        "name" : "CPG BuyStyles > Value conscious"
      }, {
        "name" : "CPG brands > Regular carbonated: Dr Pepper"
      }, {
        "name" : "CPG brands > Regular carbonated: Mountain Dew"
      }, {
        "name" : "CPG brands > Regular carbonated: Pepsi"
      }, {
        "name" : "CPG categories > Crackers"
      }, {
        "name" : "CPG categories > Frozen appetizers & snacks"
      }, {
        "name" : "CPG categories > Frozen pizza"
      }, {
        "name" : "CPG categories > Regular carbonated"
      }, {
        "name" : "Demographics > Millennials"
      }, {
        "name" : "Finance > Discretionary spending:  $20,000 - $29,999"
      }, {
        "name" : "Finance > Household income: $30,000 - $39,999"
      }, {
        "name" : "Household > Home renter"
      }, {
        "name" : "Household > Single family"
      }, {
        "name" : "Retail categories > Mass market/discount store shoppers"
      } ],
      "audienceAndAdvertisers" : {
        "numAudiences" : "589",
        "advertisers" : [ "@1981Marlen", "@ACSFX", "@ASInvestmentsUK", "@ASInvestmentsUS", "@Acura", "@AkzoNobel", "@BW_React", "@BasketsFX", "@Bitronofficial", "@BoJackHorseman", "@CBSNews", "@CharityStars", "@CocaCola", "@CommunityTV", "@DairyQueen", "@Datariuscrypto", "@DirectAutoIns", "@EdenTreeIM", "@Edison_apps", "@EricGreitens", "@Evoltobor", "@ExtraGum", "@FandangoMiles", "@GCPcloud", "@Gladskin", "@GoRebelMail", "@Google", "@GoogleHome", "@GooglePlay", "@Hallmark", "@Hellmanns", "@ING_news", "@LRDtesting", "@LinkedIn", "@LiveRampDev", "@Lumosity", "@Lympo_io", "@Microsoft", "@MobileStrike", "@MySocialData", "@NetflixBrasil", "@NetflixDE", "@NetflixFR", "@NetflixLAT", "@NetflixNL", "@NetflixUK", "@NissanJP", "@OneGramNews", "@OneUmbrellaCap", "@Oreo", "@PapaJohns", "@PurinaCatChow", "@QuickBooks", "@QuikTrip", "@RONINdata", "@RijkHoedemaker", "@Robeco", "@SUBWAY", "@SeesoTV", "@Seevibes", "@SistersMovie", "@SmirnoffUS", "@Sprite", "@Stranger_Things", "@TheEconomist", "@TheMaytagMan", "@Theot61", "@TiceGower", "@TuneCore", "@Twitter", "@TwitterSurveys", "@USChamberAction", "@VidRetal", "@Visa", "@WellsFargo", "@Wendys", "@YTAdvertisers", "@YouTubeTV", "@ZapOracles", "@belVita", "@bhillsmd", "@blackishabc", "@club4growth", "@cryptoanar", "@cspac", "@foldiebikes", "@geniesofficial", "@gokinfo", "@googlemaps", "@grownish", "@hulu", "@lovingthefilm", "@madebygoogle", "@mineroneio", "@minexcoin", "@najttaylor", "@netflix", "@noction", "@offerup", "@olivegarden", "@parksandrecnbc", "@positif_ly", "@projectfi", "@realestatechgo", "@redlobster", "@startwiseinc", "@tacobell" ]
      }
    },
    "locationHistory" : [ "Alabama, USA, USA" ]
  }
} ]