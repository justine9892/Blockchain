window.YTD.screen_name_change.part0 = [ {
  "screenNameChange" : {
    "accountId" : "860353831",
    "screenNameChange" : {
      "changedAt" : "2016-11-29T12:20:47.000Z",
      "changedFrom" : "justin7177251",
      "changedTo" : "justin71772511"
    }
  }
} ]