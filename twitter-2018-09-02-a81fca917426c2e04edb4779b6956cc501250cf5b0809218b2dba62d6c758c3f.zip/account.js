window.YTD.account.part0 = [ {
  "account" : {
    "email" : "justin7177251@outlook.com",
    "createdVia" : "oauth:640835",
    "username" : "justin71772511",
    "accountId" : "860353831",
    "createdAt" : "2012-10-03T21:11:56.000Z",
    "accountDisplayName" : "Justin",
    "timeZone" : "Central Time (US & Canada)"
  }
} ]