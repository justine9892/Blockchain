window.YTD.follower.part0 = [ {
  "follower" : {
    "accountId" : "996008184656683009"
  }
}, {
  "follower" : {
    "accountId" : "967423105458196482"
  }
}, {
  "follower" : {
    "accountId" : "965217171281457152"
  }
}, {
  "follower" : {
    "accountId" : "955799216735113218"
  }
}, {
  "follower" : {
    "accountId" : "948723200082374656"
  }
}, {
  "follower" : {
    "accountId" : "935540048958709760"
  }
}, {
  "follower" : {
    "accountId" : "894649468414566401"
  }
}, {
  "follower" : {
    "accountId" : "860105465358938112"
  }
}, {
  "follower" : {
    "accountId" : "857514133029343233"
  }
}, {
  "follower" : {
    "accountId" : "855548851754815488"
  }
}, {
  "follower" : {
    "accountId" : "855366976805363712"
  }
}, {
  "follower" : {
    "accountId" : "854759996051030017"
  }
}, {
  "follower" : {
    "accountId" : "847715133052698624"
  }
}, {
  "follower" : {
    "accountId" : "846362529907519493"
  }
}, {
  "follower" : {
    "accountId" : "846286344615739393"
  }
}, {
  "follower" : {
    "accountId" : "846111700126502916"
  }
}, {
  "follower" : {
    "accountId" : "841994614391341056"
  }
}, {
  "follower" : {
    "accountId" : "838570135476666369"
  }
}, {
  "follower" : {
    "accountId" : "832203218180513792"
  }
}, {
  "follower" : {
    "accountId" : "829616274493673472"
  }
}, {
  "follower" : {
    "accountId" : "820188907455311872"
  }
}, {
  "follower" : {
    "accountId" : "808684469963980800"
  }
}, {
  "follower" : {
    "accountId" : "806164660659560448"
  }
}, {
  "follower" : {
    "accountId" : "799007827067097092"
  }
}, {
  "follower" : {
    "accountId" : "797417245475557377"
  }
}, {
  "follower" : {
    "accountId" : "790247914253774848"
  }
}, {
  "follower" : {
    "accountId" : "786311476227084288"
  }
}, {
  "follower" : {
    "accountId" : "782035697624424448"
  }
}, {
  "follower" : {
    "accountId" : "774986368313417732"
  }
}, {
  "follower" : {
    "accountId" : "774069147110170625"
  }
}, {
  "follower" : {
    "accountId" : "773928242604539904"
  }
}, {
  "follower" : {
    "accountId" : "773722337640386560"
  }
}, {
  "follower" : {
    "accountId" : "758154792216760321"
  }
}, {
  "follower" : {
    "accountId" : "753408670420000769"
  }
}, {
  "follower" : {
    "accountId" : "752697778459938816"
  }
}, {
  "follower" : {
    "accountId" : "746526446261252096"
  }
}, {
  "follower" : {
    "accountId" : "743894481846607873"
  }
}, {
  "follower" : {
    "accountId" : "737315444252626944"
  }
}, {
  "follower" : {
    "accountId" : "727176510474440708"
  }
}, {
  "follower" : {
    "accountId" : "720560081096585216"
  }
}, {
  "follower" : {
    "accountId" : "719212130516402177"
  }
}, {
  "follower" : {
    "accountId" : "712573798072061952"
  }
}, {
  "follower" : {
    "accountId" : "4924834670"
  }
}, {
  "follower" : {
    "accountId" : "4893372793"
  }
}, {
  "follower" : {
    "accountId" : "4774185796"
  }
}, {
  "follower" : {
    "accountId" : "4591890857"
  }
}, {
  "follower" : {
    "accountId" : "4417291060"
  }
}, {
  "follower" : {
    "accountId" : "4385907798"
  }
}, {
  "follower" : {
    "accountId" : "3861082342"
  }
}, {
  "follower" : {
    "accountId" : "3347595868"
  }
}, {
  "follower" : {
    "accountId" : "3272154097"
  }
}, {
  "follower" : {
    "accountId" : "3161586402"
  }
}, {
  "follower" : {
    "accountId" : "3014801009"
  }
}, {
  "follower" : {
    "accountId" : "2806667458"
  }
}, {
  "follower" : {
    "accountId" : "2390954771"
  }
}, {
  "follower" : {
    "accountId" : "2364580981"
  }
}, {
  "follower" : {
    "accountId" : "1975850262"
  }
}, {
  "follower" : {
    "accountId" : "1162811052"
  }
}, {
  "follower" : {
    "accountId" : "1160333604"
  }
}, {
  "follower" : {
    "accountId" : "865578134"
  }
}, {
  "follower" : {
    "accountId" : "703561088"
  }
}, {
  "follower" : {
    "accountId" : "628725710"
  }
}, {
  "follower" : {
    "accountId" : "575026204"
  }
}, {
  "follower" : {
    "accountId" : "390624978"
  }
}, {
  "follower" : {
    "accountId" : "385049786"
  }
}, {
  "follower" : {
    "accountId" : "278802252"
  }
}, {
  "follower" : {
    "accountId" : "204105307"
  }
}, {
  "follower" : {
    "accountId" : "180104021"
  }
}, {
  "follower" : {
    "accountId" : "103685632"
  }
}, {
  "follower" : {
    "accountId" : "89895326"
  }
}, {
  "follower" : {
    "accountId" : "75051887"
  }
}, {
  "follower" : {
    "accountId" : "27443652"
  }
}, {
  "follower" : {
    "accountId" : "16489575"
  }
} ]