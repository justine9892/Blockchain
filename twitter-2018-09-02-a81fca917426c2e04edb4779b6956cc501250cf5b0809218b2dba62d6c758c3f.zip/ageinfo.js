window.YTD.ageinfo.part0 = [ {
  "ageMeta" : {
    "ageInfo" : {
      "age" : [ "25" ],
      "birthDate" : "1993-06-14"
    },
    "inferredAgeInfo" : {
      "age" : [ "13-54" ],
      "birthDate" : ""
    }
  }
} ]